﻿using Coles.Recharge.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Application.Functions
{
    public class PINImportExtraction
    {
        public static (List<PINHeaderDetails>,List<PINLineDetails>) Extraction(string data)
        {
            var splitFileContent = data.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            string[] header = splitFileContent[0].Split(',');
            string[] lines = splitFileContent.Skip(1).ToArray();

            var headerDetails = new PINHeaderDetails
            {
                H = header[0],
                Product_Description = header[1],
                Lines_Uploaded = Convert.ToInt32(header[2]),
                Value = header[3],
                Supplier_APN = header[4],
                ExpiryDate = DateOnly.TryParse(header[6], out DateOnly expiryDate) ? expiryDate : new DateOnly()
            };

            var pinDataDetailsList = new List<PINLineDetails>();
            foreach (var line in lines)
            {
                string[] lineDetails = line.Split(',');
                var pinDataDetails = new PINLineDetails
                {
                    SerialNumber = lineDetails[0],
                    PIN = lineDetails[1]
                };
                pinDataDetailsList.Add(pinDataDetails);
            }
            return (new List<PINHeaderDetails> { headerDetails }, pinDataDetailsList);
        }
    }
}
