﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Application.Interfaces
{
    public interface IConfigOptionsProvider<T> where T : IConfigOptionsBase
    {
        T GetConfigOptions(string configSectionName = null);
    }
}
