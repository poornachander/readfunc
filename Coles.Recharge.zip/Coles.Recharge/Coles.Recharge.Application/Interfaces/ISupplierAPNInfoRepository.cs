﻿using Coles.Recharge.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Application.Interfaces
{
    public interface ISupplierAPNInfoRepository
    {
        public Task<Products> GetProductSoftCode(string tableName,string partitionKey, string rowKey);
    }
}
