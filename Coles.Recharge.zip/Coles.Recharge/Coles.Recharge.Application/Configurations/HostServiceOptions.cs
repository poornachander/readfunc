﻿using Coles.Recharge.Application.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Application.Configurations
{
    public class HostServiceOptions:IConfigOptionsBase
    {
        public string ConfigSection { get=>"HostServiceConfiguration"; }
        public string ProductsTable { get; set; }
        public string SerialNumbersTable { get; set; }
    }
}
