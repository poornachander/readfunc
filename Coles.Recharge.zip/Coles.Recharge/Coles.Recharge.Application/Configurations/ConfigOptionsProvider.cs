﻿using Coles.Recharge.Application.Interfaces;
using Microsoft.Extensions.Configuration;

namespace Coles.Recharge.Application.Configurations
{
    public class ConfigOptionsProvider<T>:IConfigOptionsProvider<T> where T : IConfigOptionsBase, new()
    {
        private readonly IConfiguration _configuration;

        public ConfigOptionsProvider(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public T GetConfigOptions(string configSectionName = null)
        {
            T options = new T();
            _configuration.GetSection(configSectionName ?? options.ConfigSection).Bind(options);
            return options;
        }
    }
}
