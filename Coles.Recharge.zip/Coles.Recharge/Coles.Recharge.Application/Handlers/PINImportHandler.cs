﻿using Coles.Recharge.Application.Commands;
using Coles.Recharge.Application.Configurations;
using Coles.Recharge.Application.Functions;
using Coles.Recharge.Application.Interfaces;
using Coles.Recharge.Application.Response;
using Coles.Recharge.Domain.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Application.Handlers
{
    public class PINImportHandler : IRequestHandler<PINImportCommand, PINImportResponse>
    {
        private readonly HostServiceOptions _hostServiceOptions;
        private readonly ISupplierAPNInfoRepository _supplierAPNInfoRepository;
        public PINImportHandler(IConfigOptionsProvider<HostServiceOptions> _hostServiceOptionsProvider)
        {
            _hostServiceOptions = _hostServiceOptionsProvider.GetConfigOptions();
        }

        public async Task<PINImportResponse> Handle(PINImportCommand request,CancellationToken cancellationToken)
        {
            try
            {
                if(string.IsNullOrEmpty(request.FileContent))
                {
                    return new PINImportResponse
                    {
                        Success = false,
                        Message = "File content is empty"
                    };
                }
                if (request.FileContent.Split(new[] { "\n", "\r\n" }, StringSplitOptions.RemoveEmptyEntries)[0].Split(',').Length>7||
                    request.FileContent.Split(new[] { "\n", "\r\n" }, StringSplitOptions.RemoveEmptyEntries)[0].Split(',').Length > 0)
                {
                    return new PINImportResponse
                    {
                        Success = false,
                        Message = "Invalid Count in the no of headers"
                    };
                }
                var fileContent=PINImportExtraction.Extraction(request.FileContent);
                if (fileContent.Item1[2].Lines_Uploaded==fileContent.Item2.Count)
                {
                    return new PINImportResponse
                    {
                        Success = false,
                        Message = "The number of PIN count does not match with the number provided by the supplier"
                    };
                }

                var products=await _supplierAPNInfoRepository.GetProductSoftCode(_hostServiceOptions.ProductsTable, fileContent.Item1[4].Supplier_APN, fileContent.Item1[3].Value);
                if(string.IsNullOrEmpty(products.Product_Softcode))
                {
                    return new PINImportResponse
                    {
                        Success = false,
                        Message = $"The softcode/supplier APN does not exists for the {products.PLU_Desc}"
                    };
                }
                var pinSerialNumberDetails = new List<PINSerialNumbersDetails>();
                for(int i = 0; i < fileContent.Item1.Count; i++)
                {
                    var serialNumbersDetails = new PINSerialNumbersDetails
                    {
                        Product_Code = products.Product_Code,
                        PIN = fileContent.Item2[i].PIN,
                        SerialNumber = fileContent.Item2[i].SerialNumber,
                        ExpiryDate = fileContent.Item1[i].ExpiryDate,
                        Values = fileContent.Item1[i].Value
                    };
                }
                return new PINImportResponse
                {
                    Success = true,
                    Message = "PIN Import is successful"
                };
            }
            catch(Exception ex)
            {
                return new PINImportResponse
                {
                    Success = false,
                    Message = ex.Message
                };
            }
        }
    }
}
