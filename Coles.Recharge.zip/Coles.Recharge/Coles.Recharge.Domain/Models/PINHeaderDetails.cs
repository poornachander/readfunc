﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Domain.Models
{
    public class PINHeaderDetails
    {
        public string H { get; set; }
        public string Product_Description { get; set; }
        public int Lines_Uploaded { get; set; }
        public string Value { get; set; }
        public string Supplier_APN { get; set; }
        public DateOnly ExpiryDate { get; set; }
    }
}
