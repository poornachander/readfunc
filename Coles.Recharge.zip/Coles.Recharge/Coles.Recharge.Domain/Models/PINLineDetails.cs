﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Domain.Models
{
    public class PINLineDetails
    {
        public string SerialNumber { get; set; }
        public string PIN { get; set; }
    }
}
