﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Domain.Models
{
    public class Products
    {
        public string PLU_Desc { get; set; }
        public string Product_Code { get; set; }
        public string Product_Softcode { get; set; }
        public string Value { get; set; }
        public string Name { get; set; }
        public string PLU_Data { get; set; }
        public string Denom_Text { get; set; }
        public string cmltemplate { get; set; }
    }
}
