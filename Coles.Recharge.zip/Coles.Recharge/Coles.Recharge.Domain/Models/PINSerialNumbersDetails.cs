﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Domain.Models
{
    public class PINSerialNumbersDetails
    {
        public string Product_Code { get; set; }
        public string Values { get; set; }
        public string PIN { get; set; }
        public string SerialNumber { get; set; }
        public DateOnly ExpiryDate { get; set; }
    }
}
