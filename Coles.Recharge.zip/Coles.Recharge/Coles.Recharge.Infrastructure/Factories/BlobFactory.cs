﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Coles.Recharge.Application.Interfaces;
using Coles.Recharge.Infrastructure.Configurations;
using Coles.Recharge.Infrastructure.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Infrastructure.Factories
{
    public class BlobFactory:IBlobFactory
    {
        private readonly AzureStorageConfig _azureStorageConfig;
        private readonly BlobStorageConfig _blobStorageConfig;

        public BlobFactory(IConfigOptionsProvider<AzureStorageConfig> azureStorageConfig, IConfigOptionsProvider<BlobStorageConfig> blobStorageConfig)
        {
            _azureStorageConfig = azureStorageConfig.GetConfigOptions();
            _blobStorageConfig = blobStorageConfig.GetConfigOptions();
        }

        public async Task<string> DownloadAsync(string containerName, string blobName)
        {
            var blobServiceClient = new BlobContainerClient(_azureStorageConfig.blobSerivceUri, containerName);
            var blobClient= blobServiceClient.GetBlobClient(blobName);

            if(await blobClient.ExistsAsync())
            {
                BlobProperties blobProperties = await blobClient.GetPropertiesAsync();
                var memoryStream = new MemoryStream();
                await blobClient.DownloadToAsync(memoryStream);
                memoryStream.Position = 0;
                using(var reader = new StreamReader(memoryStream))
                {
                    return await reader.ReadToEndAsync();
                }
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
