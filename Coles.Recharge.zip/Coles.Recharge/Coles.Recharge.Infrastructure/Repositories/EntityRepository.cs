﻿using Coles.Recharge.Infrastructure.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Infrastructure.Repositories
{
    public class EntityRepository:IEntityRepository
    {
        private readonly IBlobFactory _blobFactory;
        public EntityRepository(IBlobFactory blobFactory)
        {
            _blobFactory = blobFactory;
        }
        public async Task<string> ReadEntity(string containerName, string blobName)
        {
            return await _blobFactory.DownloadAsync(containerName, blobName);
        }
    }
}
