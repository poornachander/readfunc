﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Infrastructure.Interfaces
{
    public interface IEntityRepository
    {
        Task<string> ReadEntity(string containerName, string blobName);
    }
}
