﻿using Coles.Recharge.Infrastructure.Factories;
using Coles.Recharge.Infrastructure.Interfaces;
using Coles.Recharge.Infrastructure.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Coles.Recharge.Infrastructure
{
    public static class IoC
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddTransient<IEntityRepository, EntityRepository>();
            services.AddTransient<IBlobFactory, BlobFactory>();
            return services;
        }
    }
}
