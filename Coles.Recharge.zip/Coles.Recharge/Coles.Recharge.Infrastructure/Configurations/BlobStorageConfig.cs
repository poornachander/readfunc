﻿using Coles.Recharge.Application.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Infrastructure.Configurations
{
    public class BlobStorageConfig : IConfigOptionsBase
    {
        public string ConfigSection { get=>"BlobStorageConfiguration"; }
        public string PinFilesContainer { get; set; }
        public string PinFilesArchiveContainer { get; set; }
        public string PinFilesErrorContainer { get; set; }
    }
}
