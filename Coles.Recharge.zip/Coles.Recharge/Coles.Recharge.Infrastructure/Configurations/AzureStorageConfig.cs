﻿using Coles.Recharge.Application.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Infrastructure.Configurations
{
    public class AzureStorageConfig:IConfigOptionsBase
    {
        public string ConfigSection { get=>"AzureWebJobsStorage"; }
        public string accountName { get; set; }
        public string blobSerivceUri { get; set; }
        public string tableServiceUri { get; set; }
        public string credential { get; set; }
    }
}
