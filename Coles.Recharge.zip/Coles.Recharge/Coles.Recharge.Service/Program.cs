using Coles.Recharge.Infrastructure;
using Coles.Recharge.Service;
using Coles.Recharge.Persistence;
using Coles.Recharge.Application;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Reflection;

public class Program
{
    public static void Main(string[] args)
    {
       
        var host = new HostBuilder()
            .ConfigureFunctionsWorkerDefaults()
            .ConfigureServices((hostingContext,services) =>
            {
                var configuration=hostingContext.Configuration;
                services.AddApplicationInsightsTelemetryWorkerService();
                services.ConfigureFunctionsApplicationInsights();
                services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly()));
                services.AddInfrastructure(configuration);
                services.AddPersistence(configuration);
                services.AddApplication();
            })
            .Build();

        host.Run();
    }
}
