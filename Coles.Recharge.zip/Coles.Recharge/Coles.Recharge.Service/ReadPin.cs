using System.IO;
using System.Threading.Tasks;
using Coles.Recharge.Application.Commands;
using Coles.Recharge.Application.Interfaces;
using Coles.Recharge.Infrastructure.Configurations;
using Coles.Recharge.Infrastructure.Interfaces;
using MediatR;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace Coles.Recharge.Service
{
    public class ReadPin
    {
        private readonly ILogger<ReadPin> _logger;
        private readonly IEntityRepository _entityRepository;
        private readonly IMediator _mediator;
        private readonly BlobStorageConfig _blobStorageConfig;
        public ReadPin(ILogger<ReadPin> logger,IEntityRepository entityRepository,
            IConfigOptionsProvider<BlobStorageConfig> blobStorageOptionsProvider,
            IMediator mediator)
        {
            _logger = logger;
            _entityRepository = entityRepository;
            _blobStorageConfig = blobStorageOptionsProvider.GetConfigOptions();
        }

        [Function(nameof(ReadPin))]
        public async Task Run([BlobTrigger("samples-workitems/{name}", Connection = "Azure")] Stream stream, string name)
        {
            var extractSerialNumber = await _mediator.Send(new PINImportCommand()
            {
                FileName = name,
                FileContent = await _entityRepository.ReadEntity(_blobStorageConfig.PinFilesContainer, name)
            });
            using var blobStreamReader = new StreamReader(stream);
            var content = await blobStreamReader.ReadToEndAsync();
            _logger.LogInformation($"C# Blob trigger function Processed blob\n Name: {name} \n Data: {content}");
        }
    }
}
