﻿using Azure.Data.Tables;
using Coles.Recharge.Application.Interfaces;
using Coles.Recharge.Domain.Models;
using Coles.Recharge.Infrastructure.Configurations;
using Coles.Recharge.Persistence.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Persistence.Repositories
{
    public class SupplierAPNInfoRepository:ISupplierAPNInfoRepository
    {
        private readonly AzureStorageConfig _azureStorageConfig;
        private TableServiceClient _tableServiceClient;

        public SupplierAPNInfoRepository(IConfigOptionsProvider<AzureStorageConfig> azureStorageConfig)
        {
            _azureStorageConfig = azureStorageConfig.GetConfigOptions();
            _tableServiceClient = new TableServiceClient(_azureStorageConfig.blobSerivceUri);
        }

        public async Task<Products> GetProductSoftCode(string tableName, string partitionKey, string rowKey)
        {
            var tableClient = _tableServiceClient.GetTableClient(tableName);
            var response=await tableClient.GetEntityAsync<ProductsEntity>(partitionKey, rowKey);
            return new Products()
            {
                PLU_Desc = response.Value.PLU_Desc ?? string.Empty,
                Product_Code = response.Value.Product_Code ?? string.Empty,
                Product_Softcode = response.Value.Product_Softcode ?? string.Empty,
                Value = response.Value.Value ?? string.Empty,
                Name = response.Value.Name ?? string.Empty,
                PLU_Data = response.Value.PLU_Data ?? string.Empty,
                Denom_Text = response.Value.Denom_Text ?? string.Empty,
                cmltemplate = response.Value.cmltemplate ?? string.Empty
            };
        }
    }
}
