﻿using Coles.Recharge.Application.Interfaces;
using Coles.Recharge.Persistence.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Persistence
{
    public static class IoC
    {
        public static IServiceCollection AddPersistence(this IServiceCollection services,IConfiguration configuration)
        {
            services.AddTransient<ISupplierAPNInfoRepository, SupplierAPNInfoRepository>();
            return services;
        }
    }
}
