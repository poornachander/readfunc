﻿using Azure;
using Azure.Data.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Persistence.Dto
{
    public class ProductsEntity:ITableEntity
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public ETag ETag { get; set; } = default;
        public DateTimeOffset? Timestamp { get; set; } = default;

        public ProductsEntity()
        {
        }

        public ProductsEntity(string partitionKey, string rowKey)
        {
            PartitionKey = partitionKey;
            RowKey = rowKey;
        }

        public string PLU_Desc { get; set; }
        public string Product_Code { get; set; }
        public string Product_Softcode { get; set; }
        public string Value { get; set; }
        public string Name { get; set; }
        public string PLU_Data { get; set; }
        public string Denom_Text { get; set; }
        public string cmltemplate { get; set; }
    }
}
