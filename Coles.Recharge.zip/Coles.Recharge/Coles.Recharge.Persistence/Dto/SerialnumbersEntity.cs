﻿using Azure;
using Azure.Data.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coles.Recharge.Persistence.Dto
{
    public class SerialnumbersEntity:ITableEntity
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
        public SerialnumbersEntity() { }
        public SerialnumbersEntity(string Product_Code, string SerialNumber)
        {
            this.PartitionKey = Product_Code;
            this.RowKey = SerialNumber;
        }

        public string BatchNumber { get; set; }
        public string Product_Code { get; set; }
        public string SerialNumber { get; set; }
        public string PIN { get; set; }
        public DateOnly ExpiryDate { get; set; }
        public string TransactionID { get; set; }
        public string ClerkName { get; set; }
        public string Cost { get; set; }
        public string Currency { get; set; }
        public int ExchangeRate { get; set; }
        public int ForeignCost { get; set; }
        public string BOMProduct { get; set; }
        public string TerminalID { get; set; }
        public string TransactionCompleteFlag { get; set; }
        public DateTime PINSoldDate { get; set; }
        public DateTime PINRequestDate { get; set; }
        public string MerchantID { get; set; }
        public string PINRefundFlag { get; set; }
        public string PINRefundReason { get; set; }
        public string RefundTransactionID { get; set; }
        public string RefundClerkName { get; set; }
        public DateTime RefundDateTime { get; set; }
    }
}
